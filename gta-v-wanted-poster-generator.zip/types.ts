export interface WantedData {
  name: string;
  crime: string;
  bounty: number;
  photoUrl: string;
  issueTimestamp: number;
}
